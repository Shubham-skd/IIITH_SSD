index page has css style1.css


Student record has css style2.css

